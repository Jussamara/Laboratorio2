/**pacote con duas classes auxiliares DataUtil que implementa metodos de tipos e formatos de datas e
 * a classe console que implementa metodos imprimir conforme a variavel declarada String, int, double etc.
 * @author Jussamara
 */
package util;
