/**Pacote de classes objeto, com seus atributos e metodos necessarios para desenvolcer o codigo.
 *@author Jussamara
 */
package model;
