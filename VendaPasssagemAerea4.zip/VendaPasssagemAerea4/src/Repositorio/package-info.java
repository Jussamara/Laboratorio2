/**pacote com as classes repositorio dos objetos, com as listas e metodos de verificação.
 * @author Jussamara
 */
package Repositorio;
