/**contem a classe que executa e roda o codigo passando e visualizando todos os menus do pacote view.menu
 * @author Jussamara
 *
 */
package vendapasssagemaerea;
