package javafxmvc.model.domain;



import java.io.Serializable;
import java.sql.Date;

public class Voo implements Serializable {

    private int idvoo;
    private String origem;
    private String destino;
    private Date horario;
    private int quantidade;
    private Aviao aviao;
  

    public Voo() {
    }

    public Voo(int voo, String origem, String destino, Date horario, int quantidade) {
        this.idvoo = voo;
        this.origem = origem;
        this.destino = destino;
        this.horario = horario;
        this.quantidade = quantidade;
    }


    public int getIdvoo() {
        return idvoo;
    }

    public void setIdvoo(int idvoo) {
        this.idvoo = idvoo;
    }

    public String getOrigem() {
        return origem;
    }

    public void setOrigem(String origem) {
        this.origem = origem;
    }

    public String getDestino() {
        return destino;
    }

    public void setDestino(String destino) {
        this.destino = destino;
    }

    public Date getHorario() {
        return horario;
    }

    public void setHorario(Date horario) {
        this.horario = horario;
    }

    public Aviao getAviao() {
        return aviao;
    }

    public void setAviao(Aviao aviao) {
        this.aviao = aviao;
    }


    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

  

    @Override
    public String toString() {
        return this.origem;
    }
    
}
