package javafxmvc.model.domain;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.Date;


public class Venda implements Serializable {

    private int idVenda;
    private Aviao id_aviao; 
    private Cliente cliente;
    private Voo voo;
    private Date horaCompra;
    private int qtdcomprada;
    
      public Venda() {
    }

     public Venda(int id, Aviao id_aviao,Cliente cliente, Voo voo, Date horaCompra, int qtdcomprada) {
        this.idVenda=id;
        this.id_aviao=id_aviao;
        this.cliente = cliente;
        this.voo = voo;
        this.horaCompra = horaCompra;
        this.qtdcomprada=qtdcomprada;
        }

    public int getIdVenda() {
        return idVenda;
    }

    public void setIdVenda(int id) {
        this.idVenda = id;
    }

    public Aviao getId_aviao() {
        return id_aviao;
    }

    public void setId_aviao(Aviao id_aviao) {
        this.id_aviao = id_aviao;
    }

    public Voo getVoo() {
        return voo;
    }

    public void setVoo(Voo voo) {
        this.voo = voo;
    }

    public Date getHoraCompra() {
        return horaCompra;
    }

    public void setHoraCompra(Date horaCompra) {
        this.horaCompra = horaCompra;
    }

    public int getQtdcomprada() {
        return qtdcomprada;
    }

    public void setQtdcomprada(int qtdcomprada) {
        this.qtdcomprada = qtdcomprada;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }
    
}
