package javafxmvc.model.domain;

import java.io.Serializable;

public class Aviao implements Serializable {
    
    private int idAviao;
    private int qtdAssentos;
    private String nomeAviao;
    
    public Aviao(){
    }

    public Aviao(int idAviao,int qtdAssentos, String nomeAviao) {
        this.idAviao = idAviao;
        this.qtdAssentos =qtdAssentos;
        this.nomeAviao = nomeAviao;
    }
       public int getIdAviao() {
        return idAviao;
    }

    public void setIdAviao(int idAviao) {
        this.idAviao = idAviao;
    }
       public int getQtdAssentos() {
        return qtdAssentos;
    }

    public void setQtdAssentos(int qtdAssentos) {
        this.qtdAssentos = qtdAssentos;
    }
    
    public String getNomeAviao() {
        return nomeAviao;
    }

    public void setNomeAviao(String nomeAviao) {
        this.nomeAviao = nomeAviao;
    }

    @Override
    public String toString() {
        return this.nomeAviao;
    }
    
}
