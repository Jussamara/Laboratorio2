package javafxmvc.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafxmvc.model.domain.Aviao;

public class AviaoDAO {

    private Connection connection;

    public Connection getConnection() {
        return connection;
    }

    public void setConnection(Connection connection) {
        this.connection = connection;
    }

    public boolean inserir(Aviao aviao) {
        String sql = "INSERT INTO aviao(nomeAviao) VALUES(?)";
        try {
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setString(1, aviao.getNomeAviao());
            stmt.execute();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(AviaoDAO.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }

    public boolean alterar(Aviao aviao) {
        String sql = "UPDATE aviao SET nomeAviao=? WHERE IdAviao=?";
        try {
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setString(1, aviao.getNomeAviao());
            stmt.setInt(2, aviao.getQtdAssentos());
            stmt.execute();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(AviaoDAO.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }

    public boolean remover(Aviao aviao) {
        String sql = "DELETE FROM aviao WHERE idAviao=?";
        try {
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setInt(1, aviao.getIdAviao());
            stmt.execute();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(AviaoDAO.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }

    public List<Aviao> listar() {
        String sql = "SELECT * FROM aviao";
        List<Aviao> retorno = new ArrayList<>();
        try {
            PreparedStatement stmt = connection.prepareStatement(sql);
            ResultSet resultado = stmt.executeQuery();
            while (resultado.next()) {
                Aviao aviao = new Aviao();
                aviao.setIdAviao(resultado.getInt("IdAviao"));
                aviao.setNomeAviao(resultado.getString("nomeAviao"));
                retorno.add(aviao);
            }
        } catch (SQLException ex) {
            Logger.getLogger(AviaoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return retorno;
    }

    public Aviao buscar(Aviao aviao) {
        String sql = "SELECT * FROM aviao WHERE idAviao=?";
        Aviao retorno = new Aviao();
        try {
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setInt(1, aviao.getIdAviao());
            ResultSet resultado = stmt.executeQuery();
            if (resultado.next()) {
                aviao.setNomeAviao(resultado.getString("nomeAviao"));
                retorno = aviao;
            }
        } catch (SQLException ex) {
            Logger.getLogger(AviaoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return retorno;
    }
}
