package javafxmvc.model.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafxmvc.model.domain.Cliente;
import javafxmvc.model.domain.Venda;
import javafxmvc.model.domain.Voo;


public class VendaDAO {

    private Connection connection;

    public Connection getConnection() {
        return connection;
    }

    public void setConnection(Connection connection) {
        this.connection = connection;
    }

    public boolean inserir(Venda venda) {
        String sql = "INSERT INTO vendas(data, idVoo, qtdcomprada, idCliente) VALUES(?,?,?,?)";
        try {
            PreparedStatement stmt = connection.prepareStatement(sql);
            java.sql.Date dataSql = new java.sql.Date(venda.getHoraCompra().getTime());
            stmt.setDate(1, dataSql);
            stmt.setInt(2, venda.getVoo().getIdvoo());
            stmt.setInt(3,venda.getQtdcomprada());
            stmt.setInt(4, venda.getCliente().getCdCliente());
            stmt.execute();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(VendaDAO.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }

    public boolean alterar(Venda venda) {
        String sql = "UPDATE clientes SET data=?, idVoo=?, qtdcomprada=?, idCliente=? WHERE idVenda=?";
        try {
            PreparedStatement stmt = connection.prepareStatement(sql);
             java.sql.Date dataSql = new java.sql.Date(venda.getHoraCompra().getTime());
            stmt.setDate(3, dataSql);
            stmt.setInt(2, venda.getVoo().getIdvoo());
            stmt.setInt(3,venda.getQtdcomprada());
            stmt.setInt(4, venda.getCliente().getCdCliente());
            stmt.setInt(5, venda.getIdVenda());
            stmt.execute();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(VendaDAO.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }

    public boolean remover(Venda venda) {
        String sql = "DELETE FROM vendas WHERE IdVenda=?";
        try {
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setInt(1, venda.getIdVenda());
            stmt.execute();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(VendaDAO.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }

    public List<Venda> listar() {
        String sql = "SELECT * FROM vendas";
        //List<Venda> listaVendas= new ArrayList<>();
        List<Venda> listaVendas = new ArrayList<>();
        try {
            PreparedStatement stmt = connection.prepareStatement(sql);
            ResultSet resultado = stmt.executeQuery();
            while (resultado.next()) {
                Venda venda = new Venda();
                Cliente cliente = new Cliente();
                venda.setIdVenda(resultado.getInt("IdVenda"));
                java.sql.Date dataSql = resultado.getDate("horacompra");
                java.util.Date dataUtil = new java.util.Date(dataSql.getTime());
                venda.setHoraCompra(resultado.getDate("data"));     
                venda.setQtdcomprada(resultado.getInt("qtdComprada"));
                cliente.setCdCliente(resultado.getInt("cdCliente"));

                //Obtendo os dados completos do Cliente associado à Venda
                ClienteDAO clienteDAO = new ClienteDAO();
                clienteDAO.setConnection(connection);
                cliente = clienteDAO.buscar(cliente);
                Voo voo = new Voo();
                voo.setIdvoo(resultado.getInt("IdVoo"));
                venda.setCliente(cliente);
                
                listaVendas.add(venda);
            }
        } catch (SQLException ex) {
            Logger.getLogger(VendaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return listaVendas;
    }

    public Venda buscar(Venda venda) {
        String sql = "SELECT * FROM vendas WHERE idVenda=?";
        Venda retorno = new Venda();
        try {
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setInt(1, venda.getIdVenda());
            ResultSet resultado = stmt.executeQuery();
            if (resultado.next()) {
                Cliente cliente = new Cliente();
                Voo voo = new Voo();
                venda.setIdVenda(resultado.getInt("idVenda"));
                venda.setHoraCompra(resultado.getDate("data"));     
                venda.setQtdcomprada(resultado.getInt("qtdComprada"));
                voo.setIdvoo(resultado.getInt("IdVoo"));
                venda.setVoo(voo);
                cliente.setCdCliente(resultado.getInt("IdCliente"));
                venda.setCliente(cliente);
                retorno = venda;
            }
        } catch (SQLException ex) {
            Logger.getLogger(VendaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return retorno;
    }

    public Venda buscarUltimaVenda() {
        String sql = "SELECT max(idVenda) FROM vendas";
        Venda retorno = new Venda();
        try {
            PreparedStatement stmt = connection.prepareStatement(sql);
            ResultSet resultado = stmt.executeQuery();

            if (resultado.next()) {
                retorno.setIdVenda(resultado.getInt("max"));
                return retorno;
            }
        } catch (SQLException ex) {
            Logger.getLogger(VendaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return retorno;
    }

    public Map<Integer, ArrayList> listarQuantidadeVendasPorMes() {
        String sql = "select count(IdVenda), extract(year from data) as ano, extract(month from data) as mes from vendas group by ano, mes order by ano, mes";
        Map<Integer, ArrayList> retorno = new HashMap();
        
        try {
            PreparedStatement stmt = connection.prepareStatement(sql);
            ResultSet resultado = stmt.executeQuery();

            while (resultado.next()) {
                ArrayList linha = new ArrayList();
                if (!retorno.containsKey(resultado.getInt("ano")))
                {
                    linha.add(resultado.getInt("mes"));
                    linha.add(resultado.getInt("count"));
                    retorno.put(resultado.getInt("ano"), linha);
                }else{
                    ArrayList linhaNova = retorno.get(resultado.getInt("ano"));
                    linhaNova.add(resultado.getInt("mes"));
                    linhaNova.add(resultado.getInt("count"));
                }
            }
            return retorno;
        } catch (SQLException ex) {
            Logger.getLogger(VendaDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return retorno;
    }
}
