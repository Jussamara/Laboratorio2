package javafxmvc.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafxmvc.model.domain.Aviao;
import javafxmvc.model.domain.Voo;

public class VooDAO {

    private Connection connection;

    public Connection getConnection() {
        return connection;
    }

    public void setConnection(Connection connection) {
        this.connection = connection;
    }

    public boolean inserir(Voo voo) {
        String sql = "INSERT INTO voo(origem, destino, quantidade, idAviao) VALUES(?,?,?,?)";
        try {
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setString(1, voo.getOrigem());
            stmt.setString(2, voo.getDestino());
            stmt.setInt(3, voo.getQuantidade());
            stmt.setInt(4, voo.getAviao().getIdAviao());
            stmt.execute();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(VooDAO.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }

    public boolean alterar(Voo voo) {
        String sql = "UPDATE voo SET origem=?, destino=?, quantidade=?, idAviao=? WHERE idVoo=?";
        try {
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setString(1, voo.getOrigem());
            stmt.setString(2, voo.getDestino());
            stmt.setInt(3, voo.getQuantidade());
            stmt.setInt(4, voo.getAviao().getIdAviao());
            stmt.setInt(5, voo.getIdvoo());
            stmt.execute();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(VooDAO.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }

    public boolean remover(Voo voo) {
        String sql = "DELETE FROM voo WHERE cdCliente=?";
        try {
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setInt(1, voo.getIdvoo());
            stmt.execute();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(VooDAO.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }

    public List<Voo> listar() {
        String sql = "SELECT * FROM voo";
        List<Voo> retorno = new ArrayList<>();
        try {
            PreparedStatement stmt = connection.prepareStatement(sql);
            ResultSet resultado = stmt.executeQuery();
            while (resultado.next()) {
                Voo voo = new Voo();
                Aviao aviao = new Aviao();
                voo.setIdvoo(resultado.getInt("idVoo"));
                voo.setOrigem(resultado.getString("origem"));
                voo.setDestino(resultado.getString("destino"));
                voo.setQuantidade(resultado.getInt("quantidade"));
                aviao.setIdAviao(resultado.getInt("IdAviao"));
                
                //Obtendo os dados completos da Aviao associada ao Voo
                AviaoDAO aviaoDAO = new AviaoDAO();
                aviaoDAO.setConnection(connection);
                aviao = aviaoDAO.buscar(aviao);
                
                voo.setAviao(aviao);
                retorno.add(voo);
            }
        } catch (SQLException ex) {
            Logger.getLogger(VooDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return retorno;
    }
    
    public List<Voo> listarPorCategoria(Aviao aviao) {
        String sql = "SELECT * FROM voo WHERE idAviao=?";
        List<Voo> lista = new ArrayList<>();
        try {
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setInt(1, aviao.getIdAviao());
            ResultSet resultado = stmt.executeQuery();
            while (resultado.next()) {
                Voo voo = new Voo();
                voo.setIdvoo(resultado.getInt("idVoo"));
                voo.setOrigem(resultado.getString("origem"));
                voo.setDestino(resultado.getString("destino"));
                voo.setQuantidade(resultado.getInt("quantidade"));
                aviao.setIdAviao(resultado.getInt("IdAviao"));
                voo.setAviao(aviao);
                lista.add(voo);
            }
        } catch (SQLException ex) {
            Logger.getLogger(AviaoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return lista;
    }

    public Voo buscar(Voo voo) {
        String sql = "SELECT * FROM voo WHERE IdVoo=?";
        Voo buscaVoo = new Voo();
        Aviao aviao = new Aviao();
        try {
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setInt(1, voo.getIdvoo());
            ResultSet resultado = stmt.executeQuery();
            if (resultado.next()) {
                buscaVoo.setIdvoo(resultado.getInt("idVoo"));
                buscaVoo.setOrigem(resultado.getString("origem"));
                buscaVoo.setDestino(resultado.getString("destino"));
               
                buscaVoo.setQuantidade(resultado.getInt("quantidade"));
                aviao.setIdAviao(resultado.getInt("IdAviao"));
                buscaVoo.setAviao(aviao);
            }
        } catch (SQLException ex) {
            Logger.getLogger(VooDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return buscaVoo;
    }
}
